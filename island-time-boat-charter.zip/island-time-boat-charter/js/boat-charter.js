jQuery(document).ready(function($) {
    // Initialize form steps
    let currentStep = 1;
    const totalSteps = 6;
    
    // Show current step and hide others
    function showStep(step) {
        $('.form-step').removeClass('active').hide();
        $(`#step-${getStepName(step)}`).addClass('active').show();
        currentStep = step;
        
        // Special handling for date step
        if (step === 3) {
            const serviceType = $('input[name="service_type"]:checked').val();
            if (serviceType === 'bareboat') {
                $('#multi-date-section').show();
                $('#booking-date').prop('required', false);
            } else {
                $('#multi-date-section').hide();
                $('#booking-date').prop('required', true);
            }
        }
    }
    
    // Get step name from number
    function getStepName(step) {
        const stepNames = {
            1: 'service',
            2: 'boat',
            3: 'date',
            4: 'location',
            5: 'guest',
            6: 'payment'
        };
        return stepNames[step] || '';
    }
    
    // Next step handler
    $(document).on('click', '.next-step', function(e) {
        e.preventDefault();
        
        // Validate current step before proceeding
        if (!validateStep(currentStep)) {
            return;
        }
        
        // Special handling for step 1 (service selection)
        if (currentStep === 1) {
            const serviceType = $('input[name="service_type"]:checked').val();
            if (!serviceType) {
                alert('Please select a service type');
                return;
            }
            
            // Load boat options for selected service
            $.ajax({
                url: boatCharterData.ajax_url,
                type: 'POST',
                data: {
                    action: 'get_boat_options',
                    nonce: boatCharterData.nonce,
                    product_type: serviceType
                },
                beforeSend: function() {
                    $('#boat-options').html('<div class="loading">Loading boats...</div>');
                },
                success: function(response) {
                    if (response.success) {
                        $('#boat-options').html(response.data);
                        showStep(2);
                    } else {
                        alert('Error loading boat options');
                    }
                },
                error: function() {
                    alert('Error loading boat options');
                }
            });
        } 
        // For other steps
        else {
            showStep(currentStep + 1);
        }
    });
    
    // Previous step handler
    $(document).on('click', '.prev-step', function(e) {
        e.preventDefault();
        if (currentStep > 1) {
            showStep(currentStep - 1);
        }
    });
    
    // Validate current step
    function validateStep(step) {
        let isValid = true;
        
        switch(step) {
            case 1:
                if (!$('.service-option.selected').length) {
                    alert('Please select a service type');
                    isValid = false;
                }
                break;
                
            case 2:
                if (!$('.boat-option.selected').length) {
                    alert('Please select a boat');
                    isValid = false;
                }
                break;
                
            case 3:
                const serviceType = $('input[name="service_type"]:checked').val();
                if (serviceType === 'bareboat') {
                    const singleDate = $('#booking-date').val();
                    const startDate = $('#start-date').val();
                    const endDate = $('#end-date').val();
                    
                    // Validate that only one option is selected
                    if (singleDate && (startDate || endDate)) {
                        alert('Please select either a single date OR a date range, not both');
                        isValid = false;
                    } 
                    // Validate that either single date or full date range is selected
                    else if (!singleDate && (!startDate || !endDate)) {
                        alert('Please select either a single date or a complete date range');
                        isValid = false;
                    }
                    // Validate that if date range is selected, both dates are present
                    else if (!singleDate && (!startDate || !endDate)) {
                        alert('Please provide both start and end dates for date range');
                        isValid = false;
                    }
                } else {
                    // For other services, require single date
                    if (!$('#booking-date').val()) {
                        alert('Please select a date');
                        isValid = false;
                    }
                }
                break;
                
            case 4:
                if (!$('#pickup-location').val() || !$('#dropoff-location').val()) {
                    alert('Please select both pickup and dropoff locations');
                    isValid = false;
                }
                
                // Check if "other" is selected and field is filled
                if ($('#pickup-location').val() === 'other' && !$('#pickup-other').val()) {
                    alert('Please specify the pickup location');
                    isValid = false;
                }
                
                if ($('#dropoff-location').val() === 'other' && !$('#dropoff-other').val()) {
                    alert('Please specify the dropoff location');
                    isValid = false;
                }
                break;
                
            case 5:
                const requiredFields = ['#full-name', '#email', '#phone', '#guests', '#address'];
                for (const field of requiredFields) {
                    if (!$(field).val()) {
                        alert('Please fill in all required fields');
                        isValid = false;
                        break;
                    }
                }
                break;
                
            case 6:
                // Validate payment information
                if (!validatePayment()) {
                    isValid = false;
                }
                break;
        }
        
        return isValid;
    }
    
    // Validate payment information
    function validatePayment() {
        // Card number validation
        const cardNumber = $('#card-number').val().replace(/\s/g, '');
        if (!validateCardNumber(cardNumber)) {
            alert('Please enter a valid Visa or Mastercard number');
            return false;
        }
        
        // Expiration date validation
        const expiry = $('#card-expiry').val();
        if (!validateExpiry(expiry)) {
            alert('Please enter a valid expiration date in MM/YY format');
            return false;
        }
        
        // CVC validation
        const cvc = $('#card-cvc').val();
        if (!/^\d{3,4}$/.test(cvc)) {
            alert('Please enter a valid CVC (3 or 4 digits)');
            return false;
        }
        
        return true;
    }
    
    // Validate card number (Visa/Mastercard)
    function validateCardNumber(number) {
        // Visa: starts with 4, length 16
        // Mastercard: starts with 5, length 16
        const visaPattern = /^4[0-9]{15}$/;
        const mastercardPattern = /^5[1-5][0-9]{14}$/;
        
        return visaPattern.test(number) || mastercardPattern.test(number);
    }
    
    // Validate expiration date
    function validateExpiry(expiry) {
        if (!/^\d{2}\/\d{2}$/.test(expiry)) return false;
        
        const [month, year] = expiry.split('/');
        const monthInt = parseInt(month, 10);
        const yearInt = parseInt(year, 10) + 2000;
        
        if (monthInt < 1 || monthInt > 12) return false;
        
        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        const currentMonth = currentDate.getMonth() + 1;
        
        if (yearInt < currentYear) return false;
        if (yearInt === currentYear && monthInt < currentMonth) return false;
        
        return true;
    }
    
    // Initialize date pickers
    $('.date-picker').datepicker({
        dateFormat: 'yy-mm-dd',
        minDate: 0
    });
    
    // Location other fields
    $('#pickup-location, #dropoff-location').change(function() {
        const isOther = $(this).val() === 'other';
        const otherField = $(this).attr('id') === 'pickup-location' 
            ? $('#pickup-other') 
            : $('#dropoff-other');
            
        otherField.toggle(isOther);
        if (isOther) {
            otherField.prop('required', true);
        } else {
            otherField.prop('required', false);
        }
    });
    
    // Service type change handler
    $('input[name="service_type"]').change(function() {
        if ($(this).val() === 'bareboat') {
            $('#multi-date-section').show();
            $('#booking-date').prop('required', false);
        } else {
            $('#multi-date-section').hide();
            $('#booking-date').prop('required', true);
        }
    });
    
    // Card number validation and type detection
    $('#card-number').on('input', function() {
        // Remove non-digit characters
        let cardNumber = $(this).val().replace(/\D/g, '');
        if (cardNumber.length > 16) {
            cardNumber = cardNumber.substring(0,16);
        }
        
        // Format with spaces every 4 characters
        let formatted = cardNumber.replace(/(\d{4})/g, '$1 ').trim();
        $(this).val(formatted);
        
        const cardType = getCardType(cardNumber);
        $('#card-type').removeClass().text('');
        
        if (cardType) {
            $('#card-type').addClass('card-type ' + cardType).text(cardType.toUpperCase());
        }
    });
    
    // Expiry date formatting
    $('#card-expiry').on('input', function() {
        // Remove non-digit characters
        let expiry = $(this).val().replace(/\D/g, '');
        if (expiry.length > 4) {
            expiry = expiry.substring(0,4);
        }
        if (expiry.length >= 2) {
            expiry = expiry.substring(0,2) + '/' + expiry.substring(2);
        }
        $(this).val(expiry);
    });
    
    // CVC input - numbers only
    $('#card-cvc').on('input', function() {
        $(this).val($(this).val().replace(/\D/g, ''));
    });
    
    // Detect card type
    function getCardType(number) {
        if (/^4/.test(number)) return 'visa';
        if (/^5[1-5]/.test(number)) return 'mastercard';
        return '';
    }
    
    // Form submission handler
    $('#it-boat-booking-form').on('submit', function(e) {
        e.preventDefault();
        
        if (!validateStep(6)) return;
        
        const formData = {
            service_type: $('input[name="service_type"]:checked').val(),
            boat_id: $('.boat-option.selected').data('id'),
            date: $('#booking-date').val(),
            start_date: $('#start-date').val(),
            end_date: $('#end-date').val(),
            pickup_location: $('#pickup-location').val(),
            pickup_other: $('#pickup-other').val(),
            dropoff_location: $('#dropoff-location').val(),
            dropoff_other: $('#dropoff-other').val(),
            name: $('#full-name').val(),
            email: $('#email').val(),
            phone: $('#phone').val(),
            guests: $('#guests').val(),
            address: $('#address').val(),
            card_name: $('#card-name').val(),
            card_number: $('#card-number').val()
        };
        
        // Process booking
        $.ajax({
            url: boatCharterData.ajax_url,
            type: 'POST',
            data: {
                action: 'process_boat_booking',
                nonce: boatCharterData.nonce,
                ...formData
            },
            beforeSend: function() {
                $('.submit-booking').prop('disabled', true).text('Processing...');
            },
            success: function(response) {
                if (response.success) {
                    // Hide all form steps
                    $('.form-step').hide();
                    // Show confirmation
                    $('#booking-confirmation').show();
                    
                    // Populate confirmation details
                    const details = response.data.confirmation;
                    let html = `<div class="confirmation-summary">`;
                    html += `<p><strong>Booking ID:</strong> ${details.booking_id}</p>`;
                    html += `<p><strong>Service:</strong> ${details.service}</p>`;
                    html += `<p><strong>Boat:</strong> ${details.boat}</p>`;
                    html += `<p><strong>Date:</strong> ${details.date}</p>`;
                    html += `<p><strong>Pickup:</strong> ${details.pickup}</p>`;
                    html += `<p><strong>Dropoff:</strong> ${details.dropoff}</p>`;
                    html += `<p><strong>Guests:</strong> ${details.guests}</p>`;
                    html += `<p><strong>Name:</strong> ${details.name}</p>`;
                    html += `<p><strong>Email:</strong> ${details.email}</p>`;
                    html += `<p><strong>Phone:</strong> ${details.phone}</p>`;
                    html += `</div>`;
                    $('#confirmation-details').html(html);
                } else {
                    alert('Booking failed: ' + response.data);
                }
            },
            error: function() {
                alert('Error processing booking');
            },
            complete: function() {
                $('.submit-booking').prop('disabled', false).text('Complete Booking');
            }
        });
    });
    
    // Service selection handler
    $(document).on('click', '.service-option', function() {
        $('.service-option').removeClass('selected');
        $(this).addClass('selected');
        $(this).find('input[type="radio"]').prop('checked', true);
    });
    
    // Boat selection handler
    $(document).on('click', '.boat-option', function() {
        $('.boat-option').removeClass('selected');
        $(this).addClass('selected');
    });
    
    // Initialize first step
    showStep(1);
});