<?php
/**
 * Plugin Name: Island Time Boat Charter Booking
 * Description: Boat rental and charter booking system with payment processing
 * Version: 1.2
 */

defined('ABSPATH') || exit;

class IslandTime_Boat_Charter {

    public function __construct() {
        add_shortcode('boat_charter_form', [$this, 'booking_form_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        
        // AJAX handlers
        add_action('wp_ajax_get_boat_options', [$this, 'ajax_get_boat_options']);
        add_action('wp_ajax_nopriv_get_boat_options', [$this, 'ajax_get_boat_options']);
        add_action('wp_ajax_process_boat_booking', [$this, 'process_booking']);
        add_action('wp_ajax_nopriv_process_boat_booking', [$this, 'process_booking']);
    }

    public function enqueue_assets() {
        // Date picker
        wp_enqueue_style('jquery-ui', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        wp_enqueue_script('jquery-ui-datepicker');
        
        // Plugin styles
        wp_enqueue_style(
            'it-boat-charter',
            plugin_dir_url(__FILE__) . 'css/boat-charter.css',
            [],
            filemtime(plugin_dir_path(__FILE__) . 'css/boat-charter.css')
        );
        
        // Plugin script
        wp_enqueue_script(
            'it-boat-charter',
            plugin_dir_url(__FILE__) . 'js/boat-charter.js',
            ['jquery', 'jquery-ui-datepicker'],
            '1.2.0',
            true
        );
        
        // Localize script
        wp_localize_script('it-boat-charter', 'boatCharterData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('boat_booking_nonce'),
            'home_url' => home_url('/')
        ]);
    }

    public function booking_form_shortcode() {
        ob_start(); ?>
        <div class="it-boat-charter-form">
            <div class="booking-header">
                <h2>Boat Charter & Rental Reservation</h2>
            </div>
            
            <form id="it-boat-booking-form">
                <!-- Step 1: Service Type -->
                <div class="form-step active" id="step-service" data-step="1">
                    <div class="form-section">
                        <label>What Service Do You Need?</label>
                        <div class="service-options">
                            <label class="service-option">
                                <input type="radio" name="service_type" value="bareboat" required>
                                <div class="option-content">
                                    <h4>Bareboat Rental</h4>
                                    <p>Rent a boat without crew</p>
                                </div>
                            </label>
                            <label class="service-option">
                                <input type="radio" name="service_type" value="day_charter">
                                <div class="option-content">
                                    <h4>Day Charter With Captain</h4>
                                    <p>Full-day trips with experienced captain</p>
                                </div>
                            </label>
                            <label class="service-option">
                                <input type="radio" name="service_type" value="dinner_charter">
                                <div class="option-content">
                                    <h4>Dinner Charter</h4>
                                    <p>Evening dining experience on the water</p>
                                </div>
                            </label>
                        </div>
                    </div>
                    <div class="form-navigation">
                        <button type="button" class="next-step">Continue</button>
                    </div>
                </div>
                
                <!-- Step 2: Boat Selection -->
                <div class="form-step" id="step-boat" data-step="2">
                    <div class="form-section">
                        <label>Select Your Boat</label>
                        <div class="boat-options" id="boat-options"></div>
                    </div>
                    <div class="form-navigation">
                        <button type="button" class="prev-step">Back</button>
                        <button type="button" class="next-step">Continue</button>
                    </div>
                </div>
                
                <!-- Step 3: Date Selection -->
                <div class="form-step" id="step-date" data-step="3">
                    <div class="form-section">
                        <label for="booking-date">What Date Are You Looking For?</label>
                        <input type="text" id="booking-date" class="date-picker" required>
                    </div>
                    
                    <div class="form-section" id="multi-date-section" style="display:none;">
                        <label>Multiple Date Rental Options</label>
                        <div class="date-range-container">
                            <div>
                                <label>Start Date</label>
                                <input type="text" id="start-date" class="date-picker">
                            </div>
                            <div>
                                <label>End Date</label>
                                <input type="text" id="end-date" class="date-picker">
                            </div>
                        </div>
                    </div>
                    <div class="form-navigation">
                        <button type="button" class="prev-step">Back</button>
                        <button type="button" class="next-step">Continue</button>
                    </div>
                </div>
                
                <!-- Step 4: Locations -->
                <div class="form-step" id="step-location" data-step="4">
                    <div class="form-section">
                        <label for="pickup-location">Pick-up Location</label>
                        <select id="pickup-location" required>
                            <option value="">Select location</option>
                            <option value="nanny_cay">Nanny Cay</option>
                            <option value="other">Other (Specify below)</option>
                        </select>
                        <input type="text" id="pickup-other" placeholder="Specify other location" style="display:none; margin-top:10px;">
                    </div>
                    
                    <div class="form-section">
                        <label for="dropoff-location">Drop-off Location</label>
                        <select id="dropoff-location" required>
                            <option value="">Select location</option>
                            <option value="nanny_cay">Nanny Cay</option>
                            <option value="other">Other (Specify below)</option>
                        </select>
                        <input type="text" id="dropoff-other" placeholder="Specify other location" style="display:none; margin-top:10px;">
                    </div>
                    <div class="form-navigation">
                        <button type="button" class="prev-step">Back</button>
                        <button type="button" class="next-step">Continue</button>
                    </div>
                </div>
                
                <!-- Step 5: Guest Information -->
                <div class="form-step" id="step-guest" data-step="5">
                    <div class="guest-info-container">
                        <div class="form-section">
                            <label for="full-name">Full Name</label>
                            <input type="text" id="full-name" required>
                        </div>
                        
                        <div class="form-section">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" required>
                        </div>
                        
                        <div class="form-section">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" required>
                        </div>
                        
                        <div class="form-section">
                            <label for="guests">Number of Guests</label>
                            <input type="number" id="guests" min="1" required>
                        </div>
                        
                        <div class="form-section">
                            <label for="address">Address</label>
                            <textarea id="address" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="form-navigation">
                        <button type="button" class="prev-step">Back</button>
                        <button type="button" class="next-step">YOUR PAYMENT INFORMATION</button>
                    </div>
                </div>
                
                <!-- Step 6: Payment -->
                <div class="form-step" id="step-payment" data-step="6">
                    <div class="form-section">
                        <h3>Payment Information</h3>
                        <div class="payment-fields">
                            <div class="form-group">
                                <label for="card-name">Name on Card</label>
                                <input type="text" id="card-name" required>
                            </div>
                            <div class="form-group">
                                <label for="card-number">Card Number</label>
                                <input type="text" id="card-number" placeholder="0000 0000 0000 0000" required>
                                <div id="card-type" class="card-type"></div>
                            </div>
                            <div class="form-group-row">
                                <div class="form-group">
                                    <label for="card-expiry">Expiration Date</label>
                                    <input type="text" id="card-expiry" placeholder="MM/YY" required>
                                </div>
                                <div class="form-group">
                                    <label for="card-cvc">CVC</label>
                                    <input type="text" id="card-cvc" placeholder="123" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-navigation">
                        <button type="button" class="prev-step">Back</button>
                        <button type="submit" class="submit-booking">Complete Booking</button>
                    </div>
                </div>
                
                <!-- Confirmation -->
                <div id="booking-confirmation" class="confirmation-container" style="display:none;">
                    <div class="confirmation-header">
                        <div class="confirmation-icon">✓</div>
                        <h3>Booking Confirmed!</h3>
                    </div>
                    <div class="confirmation-body">
                        <div id="confirmation-details" class="confirmation-details"></div>
                        <p>A confirmation email has been sent to your address.</p>
                    </div>
                    <div class="confirmation-footer">
                        <a href="<?php echo home_url('/'); ?>" class="home-button">Return to Home</a>
                    </div>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    public function ajax_get_boat_options() {
        check_ajax_referer('boat_booking_nonce', 'nonce');
        
        $product_type = isset($_POST['product_type']) ? sanitize_text_field($_POST['product_type']) : 'bareboat';
        $boats = $this->get_boats_by_type($product_type);
        
        ob_start();
        if (!empty($boats)) {
            foreach ($boats as $boat) {
                ?>
                <div class="boat-option" data-id="<?php echo esc_attr($boat['id']); ?>">
                    <h4><?php echo esc_html($boat['name']); ?></h4>
                    <?php if ($boat['restricted']) : ?>
                        <div class="restricted">Not available for bareboat rental</div>
                    <?php endif; ?>
                </div>
                <?php
            }
        } else {
            echo '<div class="error">No boats available for this category</div>';
        }
        $output = ob_get_clean();
        
        wp_send_json_success($output);
    }
    
    private function get_boats_by_type($type) {
        return [
            'bareboat' => [
                ['id' => '15rib', 'name' => "15' RIB", 'restricted' => false],
                ['id' => '23cobia', 'name' => "23' Cobia", 'restricted' => false],
                ['id' => '32seafox', 'name' => "32' Seafox", 'restricted' => false],
                ['id' => '17rib', 'name' => "17' RIB", 'restricted' => false],
                ['id' => '28cobia', 'name' => "28' Cobia/Sailfish", 'restricted' => false]
            ],
            'day_charter' => [
                ['id' => '15rib', 'name' => "15' RIB", 'restricted' => false],
                ['id' => '23cobia', 'name' => "23' Cobia", 'restricted' => false],
                ['id' => '32seafox', 'name' => "32' Seafox", 'restricted' => false],
                ['id' => '17rib', 'name' => "17' RIB", 'restricted' => false],
                ['id' => '28cobia', 'name' => "28' Cobia/Sailfish", 'restricted' => false],
                ['id' => '34powercat', 'name' => "34' Powercat", 'restricted' => true],
                ['id' => '36rib', 'name' => "36' RIB", 'restricted' => true],
                ['id' => '37axopar', 'name' => "37' Axopar", 'restricted' => true]
            ],
            'dinner_charter' => [
                ['id' => '32seafox', 'name' => "32' Seafox", 'restricted' => false],
                ['id' => '28cobia', 'name' => "28' Cobia/Sailfish", 'restricted' => false],
                ['id' => '34powercat', 'name' => "34' Powercat", 'restricted' => false],
                ['id' => '37axopar', 'name' => "37' Axopar", 'restricted' => false]
            ]
        ][$type] ?? [];
    }

    public function process_booking() {
        check_ajax_referer('boat_booking_nonce', 'nonce');
        
        // Collect and sanitize data
        $booking_data = [
            'service_type' => sanitize_text_field($_POST['service_type']),
            'boat_id' => sanitize_text_field($_POST['boat_id']),
            'date' => sanitize_text_field($_POST['date']),
            'start_date' => sanitize_text_field($_POST['start_date'] ?? ''),
            'end_date' => sanitize_text_field($_POST['end_date'] ?? ''),
            'pickup_location' => sanitize_text_field($_POST['pickup_location']),
            'pickup_other' => sanitize_text_field($_POST['pickup_other'] ?? ''),
            'dropoff_location' => sanitize_text_field($_POST['dropoff_location']),
            'dropoff_other' => sanitize_text_field($_POST['dropoff_other'] ?? ''),
            'name' => sanitize_text_field($_POST['name']),
            'email' => sanitize_email($_POST['email']),
            'phone' => sanitize_text_field($_POST['phone']),
            'guests' => intval($_POST['guests']),
            'address' => sanitize_textarea_field($_POST['address']),
            'card_name' => sanitize_text_field($_POST['card_name']),
            'card_last4' => substr(sanitize_text_field($_POST['card_number']), -4)
        ];
        
        // Create booking ID
        $booking_id = 'BC-' . date('Ymd') . '-' . bin2hex(random_bytes(3));
        
        // Prepare confirmation
        $confirmation = [
            'booking_id' => $booking_id,
            'service' => $this->get_service_name($booking_data['service_type']),
            'boat' => $this->get_boat_name($booking_data['boat_id']),
            'date' => $booking_data['date'] ? date('F j, Y', strtotime($booking_data['date'])) : 
                      ($booking_data['start_date'] ? date('F j, Y', strtotime($booking_data['start_date'])) . ' to ' . date('F j, Y', strtotime($booking_data['end_date'])) : ''),
            'pickup' => ($booking_data['pickup_location'] === 'other') ? $booking_data['pickup_other'] : 'Nanny Cay',
            'dropoff' => ($booking_data['dropoff_location'] === 'other') ? $booking_data['dropoff_other'] : 'Nanny Cay',
            'name' => $booking_data['name'],
            'email' => $booking_data['email'],
            'phone' => $booking_data['phone'],
            'guests' => $booking_data['guests'],
            'address' => $booking_data['address']
        ];
        
        // Send emails
        $this->send_confirmation_email($confirmation);
        
        wp_send_json_success([
            'message' => 'Booking successful!',
            'confirmation' => $confirmation
        ]);
    }
    
    private function get_service_name($type) {
        $services = [
            'bareboat' => 'Bareboat Rental',
            'day_charter' => 'Day Charter With Captain',
            'dinner_charter' => 'Dinner Charter'
        ];
        return $services[$type] ?? 'Unknown Service';
    }
    
    private function get_boat_name($id) {
        $boats = [
            '15rib' => '15\' RIB',
            '23cobia' => '23\' Cobia',
            '32seafox' => '32\' Seafox',
            '17rib' => '17\' RIB',
            '28cobia' => '28\' Cobia/Sailfish',
            '34powercat' => '34\' Powercat',
            '36rib' => '36\' RIB',
            '37axopar' => '37\' Axopar'
        ];
        return $boats[$id] ?? 'Unknown Boat';
    }
    
    private function send_confirmation_email($booking) {
        $to = $booking['email'];
        $subject = 'Boat Charter Booking Confirmation - ' . $booking['booking_id'];
        
        // Modern HTML email template
        $message = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Booking Confirmation</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 10px; }
                .header { background: linear-gradient(135deg, #1a6c9c, #24a2d6); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .header h1 { margin: 0; }
                .confirmation-icon { font-size: 48px; margin-bottom: 20px; }
                .content { padding: 30px; background: #f9f9f9; border-radius: 0 0 10px 10px; }
                .details { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
                .detail-row { display: flex; border-bottom: 1px solid #eee; padding: 10px 0; }
                .detail-label { font-weight: bold; width: 40%; }
                .detail-value { width: 60%; }
                .footer { text-align: center; margin-top: 30px; color: #777; font-size: 14px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div class="confirmation-icon">✓</div>
                    <h1>Booking Confirmed!</h1>
                    <p>Your booking with Island Time Boat Charters is confirmed</p>
                </div>
                <div class="content">
                    <p>Thank you for your booking, ' . esc_html($booking['name']) . '! Here are your booking details:</p>
                    
                    <div class="details">
                        <div class="detail-row">
                            <div class="detail-label">Booking ID:</div>
                            <div class="detail-value">' . esc_html($booking['booking_id']) . '</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Service:</div>
                            <div class="detail-value">' . esc_html($booking['service']) . '</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Boat:</div>
                            <div class="detail-value">' . esc_html($booking['boat']) . '</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Date:</div>
                            <div class="detail-value">' . esc_html($booking['date']) . '</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Pick-up Location:</div>
                            <div class="detail-value">' . esc_html($booking['pickup']) . '</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Drop-off Location:</div>
                            <div class="detail-value">' . esc_html($booking['dropoff']) . '</div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Number of Guests:</div>
                            <div class="detail-value">' . esc_html($booking['guests']) . '</div>
                        </div>
                    </div>
                    
                    <p>We will contact you shortly to confirm all details and provide additional information about your trip.</p>
                    
                    <p>If you have any questions, please contact us at info@islandtime.com or call (555) 123-4567.</p>
                    
                    <div class="footer">
                        <p>Island Time Boat Charters<br>
                        Nanny Cay Marina, Tortola, British Virgin Islands<br>
                        www.islandtimebvi.com</p>
                    </div>
                </div>
            </div>
        </body>
        </html>';
        
        // Set HTML content type
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        // Send email to customer
        wp_mail($to, $subject, $message, $headers);
        
        // Send admin notification
        $admin_subject = 'New Boat Booking - ' . $booking['booking_id'];
        wp_mail(get_option('admin_email'), $admin_subject, $message, $headers);
    }
}

new IslandTime_Boat_Charter();